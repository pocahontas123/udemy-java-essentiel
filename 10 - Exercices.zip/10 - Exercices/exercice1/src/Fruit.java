public abstract class Fruit extends AbstractProduct {
    public Fruit(String nomProduit, String descriptionProduit, int prixProduit) {
        super(nomProduit, descriptionProduit, prixProduit);
    }
}
